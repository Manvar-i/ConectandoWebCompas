﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationMisCompas.Model
{
    public class Resenia
    {
        public int ReseniaID { get; set; }
        public int Rating { get; set; }
        public string Description { get; set; }
    }
}
