﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationMisCompas.Model
{
    public class Carrera
    {
        public int CarreraID { get; set; }
        public string Nombre { get; set; }
    }
}
